import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Vite configuration for the React frontend
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // Proxy API calls to Express during development (avoids CORS issues)
    proxy: {
      "/api": "http://localhost:5000",
      "/uploads": "http://localhost:5000",
    },
  },
});
